//# sourceMappingURL=asset-pipeline/test/gstringtest.js.map
console.log("This should be required by gstringtest.js");