//# sourceMappingURL=asset-pipeline/test/libs/file_a.js.map
console.log("This is File A!");