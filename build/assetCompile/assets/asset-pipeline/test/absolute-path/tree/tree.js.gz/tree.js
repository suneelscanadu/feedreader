//# sourceMappingURL=asset-pipeline/test/absolute-path/tree/tree.js.map
console.log("Tree");