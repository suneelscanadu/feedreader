//# sourceMappingURL=asset-pipeline/test/absolute-path/full-tree/full_tree.js.map
console.log("Full Tree");