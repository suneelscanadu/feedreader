//# sourceMappingURL=asset-pipeline/test/gstringtest2.js.map
console.log("This should be required by gstringtest.js");